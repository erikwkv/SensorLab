Hentet fra https://github.com/rellimmot/Sony-IMX219-Raspberry-Pi-V2-CMOS (2017-11-28)
